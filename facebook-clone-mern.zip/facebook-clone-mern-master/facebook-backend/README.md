# Setup
To run the backend, you will need to have Node.JS installed and the ability to use the command line terminal.

Navigate to facebook-backend directory using the terminal and enter ```npm install``` to install the dependencies.
Enter ```node server.js``` to start the server locally.

The server will be hosted on http://localhost:9000/
